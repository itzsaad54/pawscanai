/* Runs the model off the main thread so the page stays responsive during inference. */
importScripts('engine.js');
let engine = null;
self.onmessage = async (e) => {
  const { id, type } = e.data;
  try {
    if (type === 'init') {
      engine = new PawEngine();
      await engine.load(e.data.base);
      self.postMessage({ id, result: { ok: true } });
    } else if (type === 'predict') {
      const t0 = performance.now();
      const r = engine.predict(new Uint8ClampedArray(e.data.pixels));
      r.ms = performance.now() - t0;
      self.postMessage({ id, result: r });
    }
  } catch (err) {
    self.postMessage({ id, error: (err && err.message) || String(err) });
  }
};
