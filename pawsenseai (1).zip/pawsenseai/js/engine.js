/* PawSenseAI inference engine
 * Pure JavaScript (no libraries) forward pass of the trained MobileNetV2 cat/dog classifier.
 * Weights are the exact trained weights from cat_dog_weights.h5 with BatchNorm folded into the
 * convolutions (fp16 kernels, fp32 biases) so the model downloads as a single ~4.4 MB file. */
(function (root) {
  'use strict';

  // fp16 -> fp32 lookup table, built once
  const HALF = new Float32Array(65536);
  (function buildHalfTable() {
    for (let h = 0; h < 65536; h++) {
      const s = h & 0x8000 ? -1 : 1, e = (h >> 10) & 0x1f, m = h & 0x3ff;
      HALF[h] = e === 0 ? s * m * Math.pow(2, -24)
              : e === 31 ? (m ? NaN : s * Infinity)
              : s * (1 + m / 1024) * Math.pow(2, e - 15);
    }
  })();

  class PawEngine {
    constructor() { this.plan = null; this.W = null; this.B = null; this.ready = false; }

    /** Load plan + weights from a base URL such as "model/". */
    async load(base) {
      const [planRes, binRes] = await Promise.all([
        fetch(base + 'pawsense_web.json'), fetch(base + 'pawsense_web.bin')
      ]);
      if (!planRes.ok || !binRes.ok) throw new Error('Model files could not be downloaded (HTTP ' + planRes.status + '/' + binRes.status + ').');
      this.setModel(await planRes.json(), await binRes.arrayBuffer());
    }

    setModel(plan, buf) {
      const half = new Uint16Array(buf, 0, plan.nW);
      const W = new Float32Array(plan.nW);
      for (let i = 0; i < W.length; i++) W[i] = HALF[half[i]];
      this.W = W;
      this.B = new Float32Array(buf.slice(plan.bOffsetBytes, plan.bOffsetBytes + plan.nB * 4));
      this.plan = plan;
      // last-use table so intermediate tensors can be released early
      const last = {};
      plan.ops.forEach((op, i) => { (op.t === 'add' ? [op.a, op.b] : [op.i]).forEach(n => { last[n] = i; }); });
      this.last = last;
      this.ready = true;
    }

    /** rgba: Uint8ClampedArray (224*224*4). Returns {prob, logit}; prob = P(class index 1 = dog). */
    predict(rgba) {
      if (!this.ready) throw new Error('Model not loaded');
      const p = this.plan, [H, Wd, C] = p.input, n = H * Wd;
      const x = new Float32Array(n * C), sc = p.preprocess.scale, off = p.preprocess.offset;
      for (let i = 0, j = 0, k = 0; i < n; i++, j += 4) {
        x[k++] = rgba[j] * sc + off; x[k++] = rgba[j + 1] * sc + off; x[k++] = rgba[j + 2] * sc + off;
      }
      const T = { input_layer: x }, S = { input_layer: [H, Wd, C] };
      p.ops.forEach((op, idx) => {
        if (op.t === 'add') {
          const a = T[op.a], b = T[op.b], o = new Float32Array(a.length);
          for (let i = 0; i < o.length; i++) o[i] = a[i] + b[i];
          T[op.o] = o; S[op.o] = S[op.a];
        } else {
          const [ih, iw] = S[op.i];
          const [pt, pb, pl, pr] = op.pad;
          const oh = Math.floor((ih + pt + pb - op.k) / op.s) + 1, ow = Math.floor((iw + pl + pr - op.k) / op.s) + 1;
          const o = new Float32Array(oh * ow * op.co);
          (op.t === 'conv' ? this._conv : this._dw).call(this, T[op.i], o, ih, iw, oh, ow, op);
          T[op.o] = o; S[op.o] = [oh, ow, op.co];
        }
        [op.i, op.a, op.b].forEach(nm => { if (nm && this.last[nm] === idx && nm !== p.output) delete T[nm]; });
      });
      // global average pooling + dense(1, sigmoid)
      const f = T[p.output], [fh, fw, fc] = S[p.output], hw = p.head.w, cnt = fh * fw;
      let z = p.head.b;
      for (let c = 0; c < fc; c++) {
        let s = 0;
        for (let i = 0; i < cnt; i++) s += f[i * fc + c];
        z += (s / cnt) * hw[c];
      }
      return { logit: z, prob: 1 / (1 + Math.exp(-z)) };
    }

    _conv(inp, out, ih, iw, oh, ow, op) {
      const W = this.W, bias = this.B, k = op.k, s = op.s, ci = op.ci, co = op.co, pt = op.pad[0], pl = op.pad[2];
      const wb = op.w, bb = op.b, r6 = op.relu6;
      for (let oy = 0; oy < oh; oy++) {
        for (let ox = 0; ox < ow; ox++) {
          const ob = (oy * ow + ox) * co;
          for (let c = 0; c < co; c++) out[ob + c] = bias[bb + c];
          for (let ky = 0; ky < k; ky++) {
            const iy = oy * s - pt + ky; if (iy < 0 || iy >= ih) continue;
            for (let kx = 0; kx < k; kx++) {
              const ix = ox * s - pl + kx; if (ix < 0 || ix >= iw) continue;
              const ib = (iy * iw + ix) * ci, w0 = wb + (ky * k + kx) * ci * co;
              for (let c = 0; c < ci; c++) {
                const v = inp[ib + c]; if (v === 0) continue;
                const wo = w0 + c * co;
                for (let d = 0; d < co; d++) out[ob + d] += v * W[wo + d];
              }
            }
          }
          if (r6) for (let d = 0; d < co; d++) { const v = out[ob + d]; out[ob + d] = v < 0 ? 0 : v > 6 ? 6 : v; }
        }
      }
    }

    _dw(inp, out, ih, iw, oh, ow, op) {
      const W = this.W, bias = this.B, k = op.k, s = op.s, C = op.ci, pt = op.pad[0], pl = op.pad[2];
      const wb = op.w, bb = op.b, r6 = op.relu6;
      for (let oy = 0; oy < oh; oy++) {
        for (let ox = 0; ox < ow; ox++) {
          const ob = (oy * ow + ox) * C;
          for (let c = 0; c < C; c++) out[ob + c] = bias[bb + c];
          for (let ky = 0; ky < k; ky++) {
            const iy = oy * s - pt + ky; if (iy < 0 || iy >= ih) continue;
            for (let kx = 0; kx < k; kx++) {
              const ix = ox * s - pl + kx; if (ix < 0 || ix >= iw) continue;
              const ib = (iy * iw + ix) * C, w0 = wb + (ky * k + kx) * C;
              for (let c = 0; c < C; c++) out[ob + c] += inp[ib + c] * W[w0 + c];
            }
          }
          if (r6) for (let c = 0; c < C; c++) { const v = out[ob + c]; out[ob + c] = v < 0 ? 0 : v > 6 ? 6 : v; }
        }
      }
    }
  }

  root.PawEngine = PawEngine;
  if (typeof module !== 'undefined' && module.exports) module.exports = PawEngine;
})(typeof self !== 'undefined' ? self : this);
