/* PawSenseAI – page logic
 * - loads the model (in a Web Worker when available)
 * - handles choose / drop / paste / camera input
 * - renders the cat-vs-dog result
 */
(function () {
  'use strict';

  // Output index 0 = Cat, 1 = Dog (alphabetical folder order used by Keras image_dataset_from_directory).
  // If your training used the opposite order, swap these two names.
  var CLASS_NAMES = ['Cat', 'Dog'];
  var SIZE = 224;              // model input size
  var CONFIDENT = 0.70;        // below this the page says "not sure"
  var MAX_BYTES = 25 * 1024 * 1024;
  var MAX_HISTORY = 6;

  var $ = function (s) { return document.querySelector(s); };
  var el = {
    status: $('#model-status'), statusText: $('#model-status-text'),
    drop: $('#drop'), preview: $('#preview'),
    choose: $('#btn-choose'), camera: $('#btn-camera'), file: $('#file'), fileCam: $('#file-camera'),
    result: $('#result'), title: $('#result-title'), sub: $('#result-sub'), marker: $('#marker'),
    pCat: $('#p-cat'), pDog: $('#p-dog'), ms: $('#p-ms'), hint: $('#hint'),
    history: $('#history'), historyList: $('#history-list'),
    copy: $('#copy-code'), code: $('#code-sample')
  };

  /* ---------- Placeholder links ---------- */
  Array.prototype.forEach.call(document.querySelectorAll('a[href]'), function (a) {
    if (/YOUR[-_ ]/i.test(a.getAttribute('href'))) {
      a.classList.add('is-todo');
      a.title = 'Replace this placeholder URL in index.html';
    }
  });

  /* ---------- Inference client (worker with main-thread fallback) ---------- */
  var Inference = {
    worker: null, engine: null, nextId: 1, pending: {},

    init: function () {
      var self = this, base = new URL('model/', document.baseURI).href;
      return new Promise(function (resolve, reject) {
        var w;
        try { w = new Worker(new URL('js/worker.js', document.baseURI).href); }
        catch (e) { return reject(e); }
        w.onmessage = function (e) { self._onMessage(e); };
        w.onerror = function () { self._failAll(new Error('Worker failed to start')); };
        self.worker = w;
        self._call({ type: 'init', base: base }).then(resolve, reject);
      }).catch(function () {
        // Fallback: run on the main thread (e.g. when workers are blocked)
        if (self.worker) { self.worker.terminate(); self.worker = null; }
        return loadScript('js/engine.js').then(function () {
          self.engine = new window.PawEngine();
          return self.engine.load(base);
        });
      });
    },

    predict: function (buffer) {
      var self = this;
      if (this.worker) return this._call({ type: 'predict', pixels: buffer }, [buffer]);
      return new Promise(function (resolve, reject) {
        setTimeout(function () {   // let the UI paint the "analyzing" state first
          try {
            var t0 = performance.now();
            var r = self.engine.predict(new Uint8ClampedArray(buffer));
            r.ms = performance.now() - t0;
            resolve(r);
          } catch (e) { reject(e); }
        }, 30);
      });
    },

    _call: function (msg, transfer) {
      var self = this, id = this.nextId++;
      msg.id = id;
      return new Promise(function (resolve, reject) {
        self.pending[id] = { resolve: resolve, reject: reject };
        self.worker.postMessage(msg, transfer || []);
      });
    },
    _onMessage: function (e) {
      var d = e.data, p = this.pending[d.id];
      if (!p) return;
      delete this.pending[d.id];
      if (d.error) p.reject(new Error(d.error)); else p.resolve(d.result);
    },
    _failAll: function (err) {
      var self = this;
      Object.keys(this.pending).forEach(function (k) { self.pending[k].reject(err); delete self.pending[k]; });
    }
  };

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = src; s.onload = resolve; s.onerror = function () { reject(new Error('Could not load ' + src)); };
      document.head.appendChild(s);
    });
  }

  /* ---------- Model loading ---------- */
  var modelReady = false, modelPromise = null;

  function setStatus(state, text) {
    el.status.setAttribute('data-state', state);
    el.statusText.textContent = text;
  }
  function loadModel() {
    setStatus('loading', 'Loading model (4.4 MB)…');
    var t0 = performance.now();
    modelPromise = Inference.init().then(function () {
      modelReady = true;
      setStatus('ready', 'Model ready in ' + ((performance.now() - t0) / 1000).toFixed(1) + ' s' + (Inference.worker ? '' : ' (main thread)'));
    }).catch(function (err) {
      modelReady = false;
      setStatus('error', 'Model failed to load. Check your connection and reload the page.');
      console.error('[PawSenseAI] model load error:', err);
      throw err;
    });
    return modelPromise;
  }

  /* ---------- Image handling ---------- */
  var currentUrl = null, busy = false;

  function fileToImage(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () { resolve({ img: img, url: url }); };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('This file could not be read as an image.')); };
      img.src = url;
    });
  }

  // Stretch to 224×224 – the same resize Keras image_dataset_from_directory applied during training.
  function toPixels(img) {
    var c = document.createElement('canvas'); c.width = SIZE; c.height = SIZE;
    var x = c.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff'; x.fillRect(0, 0, SIZE, SIZE);
    x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
    x.drawImage(img, 0, 0, SIZE, SIZE);
    return x.getImageData(0, 0, SIZE, SIZE).data.buffer;
  }

  function thumb(img) {
    var c = document.createElement('canvas'); c.width = c.height = 72;
    var x = c.getContext('2d'), s = Math.min(img.naturalWidth, img.naturalHeight);
    x.drawImage(img, (img.naturalWidth - s) / 2, (img.naturalHeight - s) / 2, s, s, 0, 0, 72, 72);
    return c.toDataURL('image/jpeg', 0.7);
  }

  function setResultState(state, cls) {
    el.result.setAttribute('data-state', state);
    if (cls) el.result.setAttribute('data-class', cls); else el.result.removeAttribute('data-class');
  }
  function pct(v) { return (v * 100).toFixed(1) + '%'; }

  function showError(msg) {
    setResultState('error');
    el.title.textContent = 'Could not analyze this photo';
    el.sub.textContent = msg;
    el.pCat.textContent = el.pDog.textContent = el.ms.textContent = '–';
    el.hint.hidden = true;
  }

  function render(r) {
    var pDog = r.prob, pCat = 1 - pDog, idx = pDog >= 0.5 ? 1 : 0;
    var name = CLASS_NAMES[idx], conf = idx ? pDog : pCat, cls = name.toLowerCase();
    var sure = conf >= CONFIDENT;
    setResultState('done', sure ? cls : 'unsure');
    el.marker.style.left = (pDog * 100).toFixed(2) + '%';
    el.pCat.textContent = pct(pCat);
    el.pDog.textContent = pct(pDog);
    el.ms.textContent = r.ms >= 1000 ? (r.ms / 1000).toFixed(2) + ' s' : Math.round(r.ms) + ' ms';
    if (sure) {
      el.title.textContent = 'It’s a ' + cls + '.';
      el.sub.textContent = pct(conf) + ' confident';
      el.hint.hidden = true;
    } else {
      el.title.textContent = 'Not sure. Leaning ' + cls + '.';
      el.sub.textContent = 'Only ' + pct(conf) + ' confident';
      el.hint.hidden = false;
      el.hint.textContent = 'Try a closer, well-lit photo with a single animal. If the photo shows neither a cat nor a dog, the model still has to choose one of the two.';
    }
    return { name: name, cls: sure ? cls : 'unsure', conf: conf };
  }

  function addHistory(imgThumb, info) {
    var li = document.createElement('li'), im = document.createElement('img'), sp = document.createElement('span');
    im.src = imgThumb; im.alt = ''; im.width = 36; im.height = 36;
    sp.className = 't-' + info.cls;
    sp.textContent = (info.cls === 'unsure' ? 'Unsure, ' + info.name.toLowerCase() : info.name) + ' ' + Math.round(info.conf * 100) + '%';
    li.appendChild(im); li.appendChild(sp);
    el.historyList.insertBefore(li, el.historyList.firstChild);
    while (el.historyList.children.length > MAX_HISTORY) el.historyList.removeChild(el.historyList.lastChild);
    el.history.hidden = false;
  }

  function setBusy(on) {
    busy = on;
    el.drop.classList.toggle('is-busy', on);
    el.choose.disabled = on; el.camera.disabled = on;
  }

  async function analyzeFile(file) {
    if (busy) return;
    if (!file) return;
    if (!/^image\//.test(file.type) && !/\.(jpe?g|png|webp|gif|bmp|avif|heic)$/i.test(file.name || '')) {
      return showError('Choose an image file such as JPG, PNG or WebP.');
    }
    if (file.size > MAX_BYTES) return showError('This image is larger than 25 MB. Choose a smaller file.');

    setBusy(true);
    setResultState('busy');
    el.title.textContent = 'Analyzing…';
    el.sub.textContent = modelReady ? 'Running the model on your photo' : 'Waiting for the model to finish loading';
    el.hint.hidden = true;

    try {
      var loaded = await fileToImage(file);
      if (currentUrl) URL.revokeObjectURL(currentUrl);
      currentUrl = loaded.url;
      el.preview.src = loaded.url; el.preview.hidden = false;
      el.drop.setAttribute('data-has-image', 'true');

      await modelPromise.catch(function () { throw new Error('The model is not available. Reload the page and try again.'); });
      var r = await Inference.predict(toPixels(loaded.img));
      var info = render(r);
      addHistory(thumb(loaded.img), info);
    } catch (err) {
      showError(err.message || 'Something went wrong. Try another photo.');
      console.error('[PawSenseAI]', err);
    } finally {
      setBusy(false);
    }
  }

  /* ---------- Input wiring ---------- */
  el.choose.addEventListener('click', function () { el.file.click(); });
  el.camera.addEventListener('click', function () { el.fileCam.click(); });
  [el.file, el.fileCam].forEach(function (inp) {
    inp.addEventListener('change', function () {
      var f = inp.files && inp.files[0];
      inp.value = '';          // allow choosing the same file again
      analyzeFile(f);
    });
  });
  el.drop.addEventListener('click', function () { if (!busy) el.file.click(); });
  el.drop.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (!busy) el.file.click(); }
  });
  ['dragenter', 'dragover'].forEach(function (t) {
    el.drop.addEventListener(t, function (e) { e.preventDefault(); el.drop.classList.add('is-over'); });
  });
  ['dragleave', 'drop'].forEach(function (t) {
    el.drop.addEventListener(t, function (e) { e.preventDefault(); el.drop.classList.remove('is-over'); });
  });
  el.drop.addEventListener('drop', function (e) {
    var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    analyzeFile(f);
  });
  // Stop the browser from navigating away when a file is dropped outside the zone
  ['dragover', 'drop'].forEach(function (t) { window.addEventListener(t, function (e) { e.preventDefault(); }); });
  document.addEventListener('paste', function (e) {
    var items = (e.clipboardData && e.clipboardData.items) || [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].kind === 'file' && /^image\//.test(items[i].type)) { analyzeFile(items[i].getAsFile()); break; }
    }
  });

  /* ---------- Copy code ---------- */
  if (el.copy) {
    el.copy.addEventListener('click', function () {
      var text = el.code.textContent, done = function () {
        el.copy.textContent = 'Copied';
        setTimeout(function () { el.copy.textContent = 'Copy'; }, 1600);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, done);
      else {
        var ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta);
        ta.select(); try { document.execCommand('copy'); } catch (e) { /* ignore */ }
        document.body.removeChild(ta); done();
      }
    });
  }

  /* ---------- Public helper for testing from the console ----------
     PawSense.predictUrl('model-test.jpg')  or  PawSense.predictFile(fileObject) */
  window.PawSense = {
    predictFile: function (file) { return analyzeFile(file); },
    predictUrl: async function (url) {
      var blob = await (await fetch(url)).blob();
      return analyzeFile(new File([blob], 'image', { type: blob.type || 'image/jpeg' }));
    },
    classNames: CLASS_NAMES
  };

  loadModel().catch(function () { /* already reported in the status line */ });
})();
