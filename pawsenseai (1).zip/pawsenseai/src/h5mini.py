"""Minimal read-only HDF5 reader (superblock v0, old-style groups, contiguous/chunked-uncompressed datasets)."""
import struct, numpy as np
class H5:
    def __init__(self, path):
        self.d = open(path,'rb').read()
        assert self.d[:8]==b'\x89HDF\r\n\x1a\n'
        assert self.d[8] in (0,1), 'superblock v%d'%self.d[8]
        self.root = struct.unpack_from('<Q', self.d, 56+8)[0]
        self.locs = {}
    def u(self,fmt,off): return struct.unpack_from('<'+fmt,self.d,off)
    def msgs(self, addr):
        d=self.d; out=[]
        ver,_,n,_,hs = struct.unpack_from('<BBHII',d,addr)
        assert ver==1
        blocks=[(addr+16,hs)]
        while blocks:
            off,size=blocks.pop(0); end=off+size
            while off+8<=end:
                t,s,f=struct.unpack_from('<HHB',d,off); body=off+8
                if t==0x10:
                    o,l=struct.unpack_from('<QQ',d,body); blocks.append((o,l))
                else: out.append((t,body,s))
                off=body+s
        return out
    def heap_name(self, heap, off):
        seg=struct.unpack_from('<Q',self.d,heap+24)[0]
        s=seg+off; e=self.d.index(b'\0',s); return self.d[s:e].decode()
    def walk_btree(self, addr, heap, res):
        d=self.d; assert d[addr:addr+4]==b'TREE'
        typ,lvl,n=struct.unpack_from('<BBH',d,addr+4)
        p=addr+24+8  # skip siblings, key0
        for i in range(n):
            child=struct.unpack_from('<Q',d,p)[0]; p+=16
            if lvl>0: self.walk_btree(child,heap,res)
            else:
                assert d[child:child+4]==b'SNOD'
                ns=struct.unpack_from('<H',d,child+6)[0]
                for j in range(ns):
                    eo=child+8+j*40
                    no,oh=struct.unpack_from('<QQ',d,eo)
                    res[self.heap_name(heap,no)]=oh
    def children(self, addr):
        res={}
        for t,b,s in self.msgs(addr):
            if t==0x11:
                bt,hp=struct.unpack_from('<QQ',self.d,b); self.walk_btree(bt,hp,res)
        return res
    def dataset(self, addr):
        shape=dtype=layout=None; filt=False
        for t,b,s in self.msgs(addr):
            if t==1:
                v,r=struct.unpack_from('<BB',self.d,b)
                off=b+8 if v==1 else b+4
                shape=struct.unpack_from('<%dQ'%r,self.d,off) if r else ()
            elif t==3:
                cls=self.d[b]&0xF; size=struct.unpack_from('<I',self.d,b+4)[0]
                bits=self.d[b+1]
                if cls==1: dtype=np.dtype('<f%d'%size)
                elif cls==0: dtype=np.dtype(('<i' if bits&8 else '<u')+str(size))
                else: dtype=('other',cls,size)
            elif t==8: layout=b
            elif t==0x0B: filt=True
        assert not filt, 'filters unsupported'
        n=int(np.prod(shape)) if shape else 1
        v=self.d[layout]; cls=self.d[layout+1]
        if cls==1:
            a,sz=struct.unpack_from('<QQ',self.d,layout+2); self._last=(a,sz)
            return np.frombuffer(self.d,dtype=dtype,count=n,offset=a).reshape(shape).copy()
        if cls==0:
            sz=struct.unpack_from('<H',self.d,layout+2)[0]
            return np.frombuffer(self.d,dtype=dtype,count=n,offset=layout+4).reshape(shape).copy()
        raise NotImplementedError('layout class %d'%cls)
    def is_dataset(self, addr):
        return any(t==8 for t,_,_ in self.msgs(addr))
    def all_datasets(self, addr=None, prefix=''):
        addr=addr or self.root; out={}
        for name,a in self.children(addr).items():
            p=prefix+'/'+name
            if self.is_dataset(a):
                out[p]=self.dataset(a)
                if hasattr(self,'locs') : self.locs[p]=getattr(self,'_last',None)
            else: out.update(self.all_datasets(a,p))
        return out
