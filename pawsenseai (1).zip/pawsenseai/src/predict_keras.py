"""Classify a photo with the trained Keras model.

Usage:  python src/predict_keras.py path/to/photo.jpg
Needs:  pip install -r requirements.txt
"""
import argparse
import os
import numpy as np
import tensorflow as tf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLASS_NAMES = ["Cat", "Dog"]  # output index 0 = Cat, 1 = Dog

parser = argparse.ArgumentParser(description="PawSenseAI: cat vs dog prediction")
parser.add_argument("image", help="path to a JPG/PNG photo")
parser.add_argument("--model", default=os.path.join(ROOT, "model", "cat_dog_model.keras"))
args = parser.parse_args()

model = tf.keras.models.load_model(args.model)
img = tf.keras.utils.load_img(args.image, target_size=(224, 224))
x = np.expand_dims(tf.keras.utils.img_to_array(img), axis=0)  # raw 0-255 pixels; scaling is inside the model

p_dog = float(model.predict(x, verbose=0)[0][0])
label = CLASS_NAMES[int(p_dog >= 0.5)]
print(f"{label}  (P(dog) = {p_dog:.4f}, confidence = {max(p_dog, 1 - p_dog):.1%})")
