"""Convert the trained Keras MobileNetV2 cat/dog classifier into the compact browser format used by the website.

 - reads the architecture from model/cat_dog_model.keras (config.json inside the archive)
 - reads the trained weights from model/cat_dog_weights.h5 with a tiny pure-Python HDF5 reader (no TensorFlow needed)
 - folds every BatchNorm layer into the preceding convolution
 - writes model/pawsense_web.json (layer plan) and model/pawsense_web.bin (fp16 kernels + fp32 biases)

Usage (from the repository root):  python src/export_web_model.py
Requires only: numpy
"""
import json, zipfile, collections, sys, os, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from h5mini import H5

KERAS = os.path.join(ROOT, 'model', 'cat_dog_model.keras')
H5W = os.path.join(ROOT, 'model', 'cat_dog_weights.h5')
OUT_JSON = os.path.join(ROOT, 'model', 'pawsense_web.json')
OUT_BIN = os.path.join(ROOT, 'model', 'pawsense_web.bin')

cfg=json.loads(zipfile.ZipFile(KERAS).read('config.json'))
bb=[l for l in cfg['config']['layers'] if l['class_name']=='Functional'][0]['config']
ds=H5(H5W).all_datasets()
W={k:v for k,v in ds.items() if k.startswith('/layers/')}

def inbound(l):
    r=[]
    for n in l['inbound_nodes']:
        for a in n['args']:
            if isinstance(a,dict): r.append(a['config']['keras_history'][0])
            elif isinstance(a,list): r+= [x['config']['keras_history'][0] for x in a]
    return r

# weight lookup: Keras 3 stores weights under auto-names (conv2d, conv2d_1, ...) in layer creation order
def snake(c): return {'Conv2D':'conv2d','DepthwiseConv2D':'depthwise_conv2d','BatchNormalization':'batch_normalization'}[c]
counter=collections.Counter(); wmap={}
for l in bb['layers']:
    c=l['class_name']
    if c in ('Conv2D','DepthwiseConv2D','BatchNormalization'):
        i=counter[c]; counter[c]+=1
        name=snake(c)+('' if i==0 else '_%d'%i)
        pre='/layers/functional/layers/%s/vars/'%name
        n=4 if c=='BatchNormalization' else 1
        wmap[l['name']]=[W[pre+str(j)] for j in range(n)]
used=sum(len(v) for v in wmap.values()); print('mapped tensors',used,'of',sum(1 for k in W if '/functional/' in k))

layers={l['name']:l for l in bb['layers']}
consumers=collections.defaultdict(list)
for l in bb['layers']:
    for s in inbound(l): consumers[s].append(l['name'])

def same_pad(n,k,s):
    out=-(-n//s); tot=max((out-1)*s+k-n,0); b=tot//2; return b,tot-b

ops=[]; wblob=[]; bblob=[]; woff=0; boff=0
shapes={'input_layer':(224,224,3)}   # tensor name -> HWC
alias={}                              # layer name -> tensor name carrying its output
def T(n):
    while n in alias: n=alias[n]
    return n
pending_pad={}
names=[l['name'] for l in bb['layers']]
skip=set()
for l in bb['layers']:
    n=l['name']; c=l['class_name']
    if n in skip or c=='InputLayer': continue
    src=T(inbound(l)[0]) if inbound(l) else None
    if c=='ZeroPadding2D':
        (t,b),(lf,r)=l['config']['padding']; pending_pad[n]=(t,b,lf,r)
        alias[n]=src; shapes.setdefault(src,shapes[src]); pending_pad[n+'@src']=src
        continue
    if c in ('Conv2D','DepthwiseConv2D'):
        cf=l['config']; k=cf['kernel_size'][0]; s=cf['strides'][0]
        raw_src=inbound(l)[0]
        h,w_,ci=shapes[src]
        if cf['padding']=='same': pt,pb=same_pad(h,k,s); pl,pr=same_pad(w_,k,s)
        else: pt=pb=pl=pr=0
        if raw_src in pending_pad: pt,pb,pl,pr=pending_pad[raw_src]
        # following BN (+ReLU)
        bn=[x for x in consumers[n] if layers[x]['class_name']=='BatchNormalization'][0]
        g,beta,mean,var=wmap[bn]; eps=layers[bn]['config']['epsilon']
        scale=g/np.sqrt(var+eps); bias=beta-mean*scale
        kern=wmap[n][0].astype(np.float64)
        if c=='Conv2D':
            kern=kern*scale.reshape(1,1,1,-1); co=kern.shape[3]
        else:
            assert kern.shape[3]==1
            kern=(kern[:,:,:,0]*scale.reshape(1,1,-1)); co=ci
        ho=(h+pt+pb-k)//s+1; wo=(w_+pl+pr-k)//s+1
        relu=[x for x in consumers[bn] if layers[x]['class_name']=='ReLU']
        outname=relu[0] if relu else bn
        if relu: assert layers[relu[0]]['config']['max_value']==6.0
        kern=kern.astype(np.float32)
        op={'t':'conv' if c=='Conv2D' else 'dw','i':src,'o':outname,'k':k,'s':s,'pad':[pt,pb,pl,pr],'ci':ci,'co':co,
            'w':woff,'b':boff,'relu6':bool(relu),'h':h,'wd':w_}
        wblob.append(kern.ravel()); woff+=kern.size
        bblob.append(bias.astype(np.float32)); boff+=bias.size
        ops.append(op); shapes[outname]=(ho,wo,co)
        alias[n]=outname; alias[bn]=outname
        if relu: alias[relu[0]]=outname
        skip.update([bn]+relu)
        # make outname identity
        alias.pop(outname,None)
    elif c=='Add':
        a,b=[T(x) for x in inbound(l)]
        ops.append({'t':'add','a':a,'b':b,'o':n}); shapes[n]=shapes[a]
    elif c in ('BatchNormalization','ReLU'):
        raise RuntimeError('unfused '+n)
    else: raise RuntimeError(c)
out_t=T('out_relu')
head=[l for l in cfg['config']['layers'] if l['class_name']=='Dense'][0]
dw_=W['/layers/dense/vars/0']; db_=W['/layers/dense/vars/1']
plan={'input':[224,224,3],'output':out_t,'ops':ops,'head':{'w':dw_.ravel().astype(np.float32).tolist(),'b':float(db_[0])},
      'preprocess':{'scale':1/127.5,'offset':-1.0},'nW':woff,'nB':boff}
print('ops',len(ops),'kernel params',woff,'bias',boff, 'final',shapes[out_t])
Wf = np.concatenate(wblob).astype('<f2'); Bf = np.concatenate(bblob).astype('<f4')
raw = Wf.tobytes(); raw += b'\0' * ((-len(raw)) % 4)
plan['bOffsetBytes'] = len(raw)
with open(OUT_BIN, 'wb') as f: f.write(raw + Bf.tobytes())
with open(OUT_JSON, 'w') as f: json.dump(plan, f, separators=(',', ':'))
print('wrote', OUT_JSON, 'and', OUT_BIN, '(%.1f MB)' % (os.path.getsize(OUT_BIN) / 1e6))
