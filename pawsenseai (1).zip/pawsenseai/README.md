# PawSenseAI – Cat vs Dog Image Classifier

Deep Learning semester project. A MobileNetV2 transfer-learning model classifies a photo as **cat** or **dog**.
The website runs the trained model **inside the browser** (no server, no external ML library), so it deploys on Vercel as a plain static site.

- Live site: `https://YOUR-VERCEL-URL.vercel.app`
- Report: `docs/PawSenseAI_Project_Report.pdf`
- Presentation: `docs/PawSenseAI_Presentation.pdf`
- Video: `https://www.youtube.com/watch?v=YOUR_YOUTUBE_VIDEO_ID`
- Dataset: `https://www.kaggle.com/datasets/YOUR_DATASET_SLUG`

## Repository layout

```
index.html                 Home page, live demo, all project links
css/style.css              Styles
js/engine.js               Pure-JavaScript MobileNetV2 inference engine
js/worker.js               Runs the engine in a Web Worker
js/app.js                  Upload / drop / paste / camera, result display
model/cat_dog_weights.h5   Trained weights (Keras)
model/cat_dog_model.keras  Full Keras model (architecture + weights)
model/pawsense_web.bin     Compact weights used by the website (BatchNorm folded, fp16)
model/pawsense_web.json    Layer plan for the browser engine
src/predict_keras.py       Predict with the Keras model from the command line
src/export_web_model.py    Rebuilds model/pawsense_web.* from the Keras files (needs only numpy)
src/h5mini.py              Tiny HDF5 reader used by the export script
docs/                      Report and presentation
vercel.json                Vercel headers / clean URLs
```

## Model

| | |
|---|---|
| Input | 224 × 224 RGB, raw 0–255 pixels (scaling to −1…1 is inside the model) |
| Backbone | MobileNetV2 (width 1.0) |
| Head | Global average pooling → Dropout 0.3 → Dense(1, sigmoid) |
| Output | Probability that the photo shows a **dog** (index 1); cat = index 0 |
| Loss / optimizer | Binary cross-entropy / Adam |
| Parameters | 2,259,265 |

The `.keras` and `.h5` files contain trained weights only; Adam moment estimates were zeroed to keep the repository small.

## Use the model in Python

```bash
pip install -r requirements.txt
python src/predict_keras.py my_photo.jpg
```

```python
import numpy as np, tensorflow as tf
model = tf.keras.models.load_model("model/cat_dog_model.keras")
img = tf.keras.utils.load_img("my_photo.jpg", target_size=(224, 224))
x = np.expand_dims(tf.keras.utils.img_to_array(img), 0)
p_dog = float(model.predict(x)[0][0])
```

## Run the website locally

```bash
python -m http.server 8000      # then open http://localhost:8000
```

(Opening `index.html` by double-click will not work: browsers block loading the model from `file://`.)

## Deploy on Vercel

1. Push this folder to a **public** GitHub repository.
2. On vercel.com choose **Add New → Project**, import the repository.
3. Framework Preset: **Other**. Leave Build Command and Output Directory empty. Click **Deploy**.

## Before you publish: replace the placeholders

Search `index.html` (and this README) for `YOUR` and replace:

| Placeholder | Replace with |
|---|---|
| `YOUR-GITHUB-USERNAME` | your GitHub username (fixes the repo, report and presentation links) |
| `YOUR_YOUTUBE_VIDEO_ID` | the id of your YouTube video |
| `YOUR_LINKEDIN_POST` | the tail of your LinkedIn post URL |
| `YOUR_DATASET_SLUG` | the dataset page path (or replace the whole Kaggle URL) |
| `YOUR NAME` | your name (footer) |

While a placeholder remains, the page draws a dashed outline around that link so you can spot it.
Also add your training notebook (for example `notebooks/train.ipynb`) and your dataset link/description.
