# docs/

Put the two deliverables here before you push to GitHub:

| File | What it is |
|------|------------|
| `PawSenseAI_Project_Report.pdf` | The AI-generated project report (problem, dataset, architecture, training, results) |
| `PawSenseAI_Presentation.pdf` | The presentation slides exported as PDF |

The website links to them through GitHub (`.../blob/main/docs/<file name>`), so keep the exact file names or update the two links in `index.html`.
